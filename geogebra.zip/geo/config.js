window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "GeoGebra Exam",
   "homepage": "app-offline.html",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "rotation": "0",
   "kioskEnabled": true
};