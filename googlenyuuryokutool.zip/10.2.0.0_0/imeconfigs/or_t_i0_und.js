(function(){/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';google.elements.ime.loadConfig("or-t-i0-und",{0:0,1:2,2:!0,3:!0,4:!1,5:!1,6:!1,7:!1,8:!1,9:!0,10:!1,28:!1,11:!0,12:!0,13:50,14:6,15:1,16:null,22:/[a-z]/i,27:/[^a-z\u0B00-\u0B7F]/i});}).call(this);
