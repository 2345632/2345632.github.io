(function(){/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';google.elements.ime.loadConfig("el-t-i0-und",{0:0,1:2,2:!0,3:!0,4:!1,5:!1,6:!1,7:!1,8:!1,9:!0,10:!1,28:!1,11:!0,12:!0,13:50,14:6,15:1,16:{3:["\u03be"],8:["\u03b8"],a:["\u03ac","\u03b1"],af:["\u03b1\u03c5"],av:["\u03b1\u03c5"],b:["\u03b2"],c:["\u03ba","\u03c2","\u03c3"],ch:["\u03c7"],d:["\u03b4"],dh:["\u03b4"],e:["\u03ad","\u03b1\u03b9","\u03b5"],ef:["\u03b5\u03c5"],ev:["\u03b5\u03c5"],f:["\u03c6"],g:["\u03b3","\u03b3\u03ba"],gh:["\u03b3","\u03b3\u03ba"],h:["\u03ae","\u03b7","\u03c7"],i:"\u0390 \u03ae \u03af \u03b5\u03b9 \u03b7 \u03b9 \u03bf\u03b9 \u03c5\u03b9 \u03ca".split(" "),
"if":["\u03b7\u03c5"],iv:["\u03b7\u03c5"],j:["\u03b3","\u03b3\u03ba","\u03be"],k:["\u03ba","\u03c7"],ks:["\u03be"],l:["\u03bb"],m:["\u03bc"],mb:["\u03bc\u03c0"],n:["\u03bd","\u03cb"],nd:["\u03bd\u03c4"],ng:["\u03b3\u03b3","\u03b3\u03ba"],nq:["\u03b3\u03c7"],nx:["\u03b3\u03be"],o:["\u03bf","\u03c9","\u03cc","\u03ce"],oy:["\u03bf\u03b9","\u03bf\u03c5"],p:["\u03c0"],ph:["\u03c6"],ps:["\u03c8"],q:["\u03ba"],r:["\u03c1"],rh:["\u03c1"],s:["\u03c2","\u03c3"],sh:["\u03c2","\u03c3"],t:["\u03c4"],th:["\u03b8"],
u:["\u03bf\u03c5","\u03c5","\u03cd"],v:["\u03b2"],w:["\u03b2","\u03c9","\u03ce"],x:["\u03be","\u03c7"],y:["\u03bf\u03c5","\u03c5","\u03cd"],z:["\u03b6"]},22:/[a-z`]/i,27:/[^a-z`\u0370-\u03ff]/i});}).call(this);
