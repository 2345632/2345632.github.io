(function(){/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';google.elements.ime.loadConfig("gu-t-i0-und",function(){var b={"|":"\u0964"};return{0:0,1:2,2:!0,3:!0,4:!1,5:!1,6:!1,7:!1,8:!1,9:!0,10:!1,28:!1,11:!0,12:!0,13:50,14:6,15:1,16:{".a":"\u0a82\u0a8d\u0a91\u0abc\u0abd\u0ac5\u0ac9".split(""),0:["\u0ae6"],1:["\u0ae7"],2:["\u0ae8"],3:["\u0ae9"],4:["\u0aea"],5:["\u0aeb"],6:["\u0aec"],7:["\u0aed"],8:["\u0aee"],9:["\u0aef"],a:["\u0a85"],aa:["\u0a86","\u0abe"],ah:["\u0a83"],ai:["\u0a90","\u0ac8"],am:["\u0a81","\u0a82"],an:["\u0a81","\u0a82"],ao:["\u0ab5"],aum:["\u0ad0"],
b:["\u0aac"],bh:["\u0aad"],ch:["\u0a9a","\u0a9b"],chh:["\u0a9a","\u0a9b"],d:["\u0aa1","\u0aa6","\u0ab3"],dh:["\u0aa1","\u0aa2","\u0aa6","\u0aa7","\u0ab3"],dhh:["\u0aa1","\u0aa6","\u0ab3"],du:["\u0aa6\u0ac1","\u0aa6\u0ac1\u0a83"],e:["\u0a8f","\u0ac7"],ee:["\u0a88","\u0ac0"],f:["\u0aab"],g:["\u0a97"],gh:["\u0a98"],gn:["\u0a9c\u0acd\u0a9e"],gy:["\u0a9c\u0acd\u0a9e"],h:["\u0ab9"],i:["\u0a87","\u0abf"],j:["\u0a9c","\u0a9c\u0acd"],jh:["\u0a9d"],k:["\u0a95"],kh:["\u0a96"],l:["\u0ab2","\u0ab3"],m:["\u0aae"],
n:["\u0aa3","\u0aa8"],ng:["\u0a81","\u0a82"],o:["\u0a93","\u0acb"],oo:["\u0a8a","\u0ac2"],ow:["\u0a94","\u0acc"],p:["\u0aaa"],ph:["\u0aab"],r:["\u0a8b","\u0ab0","\u0ac3","\u0ac4","\u0ae0"],rh:["\u0aa1","\u0aa6","\u0ab3"],ri:["\u0a8b","\u0ab0","\u0ac3","\u0ac4","\u0ae0"],s:["\u0ab8"],sh:["\u0ab6","\u0ab7"],t:["\u0a9f","\u0aa4"],th:["\u0a9f","\u0aa0","\u0aa4","\u0aa5"],thh:["\u0a9f","\u0aa4"],tth:["\u0a9f","\u0aa4"],u:["\u0a89","\u0ac1"],v:["\u0ab5"],w:["\u0ab5"],y:["\u0aaf"],z:["\u0a9d"]},19:function(a,
c){return b[c]?(a={back:0},a.text=b[c],a):null},22:/[a-z]/i,27:/[^a-z\u0A80-\u0AFF]/i}}());}).call(this);
