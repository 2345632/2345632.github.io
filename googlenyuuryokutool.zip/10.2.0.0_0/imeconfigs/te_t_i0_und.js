(function(){/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';google.elements.ime.loadConfig("te-t-i0-und",{0:0,1:2,2:!0,3:!0,4:!1,5:!1,6:!1,7:!1,8:!1,9:!0,10:!1,28:!1,11:!0,12:!0,13:50,14:6,15:1,16:{".a":["\u0c55","\u0c56"],0:["\u0c66"],1:["\u0c67"],2:["\u0c68"],3:["\u0c69"],4:["\u0c6a"],5:["\u0c6b"],6:["\u0c6c"],7:["\u0c6d"],8:["\u0c6e"],9:["\u0c6f"],a:["\u0c05"],aa:["\u0c06","\u0c3e"],ae:["\u0c0f","\u0c47"],ah:["\u0c03"],ai:["\u0c10","\u0c48"],am:["\u0c01","\u0c02","\u0c1e"],an:["\u0c01","\u0c02","\u0c1e"],ao:["\u0c35\u0c41"],b:["\u0c2c"],bh:["\u0c2d"],ch:["\u0c1a",
"\u0c1a\u0c4d","\u0c1a\u0c4d\u0c1a","\u0c1b"],chh:["\u0c1a","\u0c1a\u0c4d","\u0c1a\u0c4d\u0c1a","\u0c1b"],d:["\u0c21","\u0c26","\u0c26\u0c4d","\u0c27"],dh:["\u0c22","\u0c25","\u0c26","\u0c26\u0c4d\u0c26","\u0c27"],du:["\u0c26\u0c41","\u0c26\u0c41\u0c03"],e:["\u0c0e","\u0c46"],ee:["\u0c08","\u0c40"],f:["\u0c2b"],g:["\u0c17"],gh:["\u0c18"],gn:["\u0c19","\u0c1c\u0c4d\u0c1e"],gy:["\u0c19","\u0c1c\u0c4d\u0c1e"],h:["\u0c39"],i:["\u0c07","\u0c3f"],iah:["\u0c2f\u0c4d\u0c2f"],j:["\u0c1c","\u0c1c\u0c4d"],jh:["\u0c1d"],
k:["\u0c15"],kh:["\u0c16"],l:["\u0c0c","\u0c32","\u0c33","\u0c61"],m:["\u0c2e"],n:["\u0c23","\u0c28"],o:["\u0c12","\u0c4a"],oo:["\u0c0a","\u0c13","\u0c42","\u0c4b"],ow:["\u0c14","\u0c4c"],p:["\u0c2a"],ph:["\u0c2b"],r:"\u0c0b\u0c30\u0c31\u0c43\u0c44\u0c60".split(""),ru:["\u0c0b","\u0c43"],s:["\u0c38"],sh:["\u0c36","\u0c37","\u0c37\u0c4d"],sht:["\u0c37\u0c4d\u0c20"],t:["\u0c1f","\u0c24"],th:"\u0c20 \u0c24 \u0c24\u0c4d \u0c24\u0c4d\u0c24 \u0c25 \u0c27".split(" "),u:["\u0c09","\u0c41"],v:["\u0c35"],vu:["^\u0c09",
"^\u0c0a"],w:["\u0c35"],y:["\u0c2f","\u0c2f\u0c4d"]},22:/[a-z^~|@]/i,27:/[^a-z^~|@\u0C00-\u0C7F]/i});}).call(this);
